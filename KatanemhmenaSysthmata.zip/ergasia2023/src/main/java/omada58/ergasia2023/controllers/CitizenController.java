package omada58.ergasia2023.controllers;

import com.fasterxml.jackson.core.util.RequestPayload;
import omada58.ergasia2023.entities.Citizen;
import omada58.ergasia2023.entities.Doctor;
import omada58.ergasia2023.entities.Family;
import omada58.ergasia2023.service.CitizenService;
import omada58.ergasia2023.service.DoctorService;
import omada58.ergasia2023.service.FamilyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/citizen")
public class CitizenController {

    @Autowired
    private CitizenService citizenService;

    @Autowired
    private FamilyService familyService;

    @Autowired
    private DoctorService doctorService;

    // request για καταχώριση στοιχειων οικογένειας
    @PostMapping("/{citizenId}/submitFamily")
    public ResponseEntity<String> submitFamilyInfo(
            @PathVariable Integer citizenId,
            @RequestBody Family familyInfo) {

        List<Citizen> familyMembers = familyInfo.getMembers();

        citizenService.submitFamilyInfo(familyInfo, familyMembers);

        return ResponseEntity.ok("Family information submitted successfully.");
    }

    // request για εμφάνιση λιστα γιατρου
    @GetMapping("/doctors/{area}")
    public ResponseEntity<List<Doctor>> getDoctorsInArea(@PathVariable String area) {
        List<Doctor> doctors = doctorService.getDoctorsInArea(area);
        return ResponseEntity.ok(doctors);
    }

    @PostMapping("/requestDoctor/{doctorId}")
    public ResponseEntity<String> sendRequest(
            @PathVariable Integer citizenId,
            @PathVariable Integer doctorId,
            @RequestParam boolean requestValue) {
        citizenService.sendRequestToDoctor(citizenId, doctorId, requestValue);
        return ResponseEntity.ok("Request sent successfully.");
    }
}
