package omada58.ergasia2023.controllers;

import omada58.ergasia2023.entities.DoctorRequest;
import omada58.ergasia2023.entities.Family;
import omada58.ergasia2023.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/doctor")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @GetMapping("/{doctorId}/families")
    public ResponseEntity<List<Family>> getFamiliesForDoctor(@PathVariable Integer doctorId) {

        List<Family> families = doctorService.getFamiliesByDoctorId(doctorId);
        return ResponseEntity.ok(families);
    }

    @GetMapping("/{doctorId}/requests")
    public ResponseEntity<List<DoctorRequest>> getRequestsForDoctor(@PathVariable Integer doctorId) {
        List<DoctorRequest> requests = doctorService.getRequestsForDoctor(doctorId);
        return ResponseEntity.ok(requests);
    }

    @PostMapping("/{doctorId}/respondToRequest/{requestId}")
    public ResponseEntity<String> respondToRequest(
            @PathVariable Integer doctorId,
            @PathVariable Integer requestId,
            @RequestParam boolean accepted) {
        doctorService.respondToRequest(doctorId, requestId, accepted);
        return ResponseEntity.ok("Response submitted successfully.");
    }
}
