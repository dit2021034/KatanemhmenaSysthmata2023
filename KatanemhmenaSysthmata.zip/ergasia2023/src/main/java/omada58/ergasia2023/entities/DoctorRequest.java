package omada58.ergasia2023.entities;

import jakarta.persistence.*;


@Entity
@Table( name = "doctor_request")
public class DoctorRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "citizen_id")
    private Citizen citizen;

    @ManyToOne
    @JoinColumn(name = "doctor_id")
    private Doctor doctor;
    private boolean accepted;


    public Doctor getDoctor() { return doctor; }

    public boolean isAccepted() {
        return accepted;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }

    public Citizen getCitizen() {
        return citizen;
    }

    public void setCitizen(Citizen citizen) {
        this.citizen = citizen;
    }

    public DoctorRequest(Citizen citizen) {
        this.citizen = citizen;
    }

    public DoctorRequest() {
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setDoctor(Doctor doctor) {
    }
}
