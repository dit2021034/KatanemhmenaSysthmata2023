package omada58.ergasia2023.repository;

import omada58.ergasia2023.entities.DoctorRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DoctorRequestRepository extends JpaRepository<DoctorRequest, Integer> {
}
