package omada58.ergasia2023.service;

import omada58.ergasia2023.entities.Doctor;
import omada58.ergasia2023.entities.DoctorRequest;
import omada58.ergasia2023.entities.Family;
import omada58.ergasia2023.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;

    @Autowired
    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public List<Doctor> getAllDoctors() {
        return (List<Doctor>) doctorRepository.findAll();
    }

    public Optional<Doctor> getDoctorById(Integer id) { return doctorRepository.findById(id); }

    public void saveDoctor(Doctor doctor) {
        doctorRepository.save(doctor);
    }

    public void deleteDoctor(Integer id) {
        doctorRepository.deleteById(id);
    }

    public List<Doctor> getDoctorsInArea(String area) { return doctorRepository.findByArea(area); }

    public List<Family> getFamiliesByDoctorId(Integer doctorId) { return doctorRepository.findFamiliesByDoctorId(doctorId); }

    public List<DoctorRequest> getRequestsForDoctor(Integer doctorId) {
        // Implement logic to retrieve requests for the doctor
        return doctorRepository.findById(doctorId).map(Doctor::getRequests).orElse(Collections.emptyList());
    }

    public void respondToRequest(Integer doctorId, Integer requestId, boolean accepted) {
        // Implement logic to respond to a request
        Optional<Doctor> optionalDoctor = doctorRepository.findById(doctorId);
        optionalDoctor.ifPresent(doctor -> {
            Optional<DoctorRequest> optionalRequest = doctor.getRequests().stream()
                    .filter(request -> request.getId().equals(requestId))
                    .findFirst();
            optionalRequest.ifPresent(request -> {
                request.setAccepted(accepted);
                // You may want to update the database here
            });
        });
    }

    public Doctor findByUsername(String username) {
        return doctorRepository.findByUsername(username);
    }
}
