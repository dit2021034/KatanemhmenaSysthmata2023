package omada58.ergasia2023.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import omada58.ergasia2023.entities.Citizen;
import omada58.ergasia2023.entities.Doctor;
import omada58.ergasia2023.entities.DoctorRequest;
import omada58.ergasia2023.entities.Family;
import omada58.ergasia2023.repository.CitizenRepository;
import omada58.ergasia2023.repository.DoctorRepository;
import omada58.ergasia2023.repository.DoctorRequestRepository;
import omada58.ergasia2023.repository.FamilyRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CitizenService {

    private final CitizenRepository citizenRepository;
    private final FamilyRepository familyRepository;
    private final DoctorRequestRepository doctorRequestRepository;
    private final DoctorRepository doctorRepository;

    @Autowired
    public CitizenService(
            CitizenRepository citizenRepository,
            FamilyRepository familyRepository,
            DoctorRequestRepository doctorRequestRepository,
            DoctorRepository doctorRepository) {
        this.citizenRepository = citizenRepository;
        this.familyRepository = familyRepository;
        this.doctorRequestRepository = doctorRequestRepository;
        this.doctorRepository = doctorRepository;
    }

    public List<Citizen> getAllCitizens() {
        return citizenRepository.findAll();
    }

    public Optional<Citizen> getCitizenById(Integer id) {
        return citizenRepository.findById(id);
    }

    public void saveCitizen(Citizen citizen) {
        citizenRepository.save(citizen);
    }

    public void deleteCitizenById(Integer id) {
        citizenRepository.deleteById(id);
    }

    @Transactional
    public void submitFamilyInfo(Family family, List<Citizen> familyMembers) {
        familyRepository.save(family);
        familyMembers.forEach(member -> member.setFamily(family));
        citizenRepository.saveAll(familyMembers);
    }

    public void sendRequestToDoctor(Integer citizenId, Integer doctorId, boolean requestValue) {
        Optional<Citizen> optionalCitizen = citizenRepository.findById(citizenId);
        optionalCitizen.ifPresent(citizen -> {
            citizen.setRequestSent(requestValue);

        });
    }

    public void sendRequestToDoctor(Integer citizenId, Integer doctorId) {
        Optional<Citizen> citizenOptional = citizenRepository.findById(citizenId);
        Optional<Doctor> doctorOptional = doctorRepository.findById(doctorId);

        if (citizenOptional.isPresent() && doctorOptional.isPresent()) {
            Citizen citizen = citizenOptional.get();
            Doctor doctor = doctorOptional.get();

            DoctorRequest doctorRequest = new DoctorRequest(citizen);
            doctorRequestRepository.save(doctorRequest);

            doctor.addRequest(doctorRequest);
            doctorRepository.save(doctor);
        }
    }

    public Citizen findByUsername(String username) {
        return citizenRepository.findByUsername(username);
    }
}
