package omada58.ergasia2023.config;

import omada58.ergasia2023.entities.Citizen;
import omada58.ergasia2023.entities.Doctor;
import omada58.ergasia2023.service.CitizenService;
import omada58.ergasia2023.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
public class SecurityConfig {

    @Autowired
    private CitizenService citizenService;

    @Autowired
    private DoctorService doctorService;

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> {
            Citizen citizen = citizenService.findByUsername(username);
            if (citizen != null) {
                return org.springframework.security.core.userdetails.User
                        .withUsername(username)
                        .password(citizen.getPassword())
                        .roles("CITIZEN") // Assign the CITIZEN role
                        .build();
            }

            Doctor doctor = doctorService.findByUsername(username);
            if (doctor != null) {
                return org.springframework.security.core.userdetails.User
                        .withUsername(username)
                        .password(doctor.getPassword())
                        .roles("DOCTOR") // Assign the DOCTOR role
                        .build();
            }

            throw new IllegalArgumentException("User not found: " + username);
        };
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeRequests(requests ->
                        requests
                                .requestMatchers("/", "/home", "/register", "/saveUser").permitAll()
                                .requestMatchers("/citizen/**").hasRole("CITIZEN")
                                .requestMatchers("/doctor/**").hasRole("DOCTOR")
                                .anyRequest().authenticated()
                )
                .formLogin(form ->
                        form
                                .loginPage("/login")
                                .permitAll()
                )
                .logout(logout ->
                        logout
                                .permitAll()
                );

        return http.build();
    }
}
