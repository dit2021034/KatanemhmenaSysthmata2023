package omada58.ergasia2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ergasia2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
